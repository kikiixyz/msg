<p align="center">
<img src="https://raw.githubusercontent.com/MRHRTZ/DGC-ChatBotV3/main/media/img/dgc.jpg" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="DGC-ChatBotV3" src="https://img.shields.io/badge/Whatsapp Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/MRHRTZ"><img title="Author" src="https://img.shields.io/badge/Author-MRHRTZ-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/MRHRTZ/DGC-ChatBotV3/network/members"><img title="Forks" src="https://img.shields.io/github/forks/MRHRTZ/DGC-ChatBotV3?color=red&style=flat-square"></a>
<a href="https://github.com/MRHRTZ/DGC-ChatBotV3/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/MRHRTZ/DGC-ChatBotV3?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/MRHRTZ/DGC-ChatBotV3"><img title="Followers" src="https://img.shields.io/github/followers/MRHRTZ?color=blue&style=flat-square"></a>
<a href="https://github.com/MRHRTZ/DGC-ChatBotV3/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/MRHRTZ/DGC-ChatBotV3?color=red&style=flat-square"></a>
</p>


# DGC-ChatBotV3
>Personal Bot DGC WhatsApp, including unique fiture like group commands downloader and other unique thing thats bot for Whatsapp. 

# Required
- Node 12.19.0
- Npm 6.14.8
- ImageMagick-7.0.10-34-Q16-HDRI <a href=https://imagemagick.org/script/download.php#windows>Here</a>

# Installing Step

```
git clone https://github.com/MRHRTZ/DGC-ChatBotV3

cd DGC-ChatBotV3/

[For linux = sudo apt-get install npm]

[For Windows = (install manual from https://nodejs.org>) 

npm i

npm start
```

# Bug? 
- If find a bugs please contact me on <a href=https://wa.me/6285559038021>WhatsApp</a>
